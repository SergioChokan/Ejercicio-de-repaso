function fokus() {
   /* document.getElementById("focblu").style.backgroundColor = "red";*/
    let cambiar = document.getElementById("focblu");
    cambiar.style.backgroundColor='Red';
}

function blup() {
    let cambiar = document.getElementById("focblu");
    cambiar.style.backgroundColor='Green';
}

function ccolor() {
    /*let parafo = document.getElementById("parafo");*/
    document.getElementById("parafo").style.backgroundColor = "red";
}

function quitar() {
    /*let parafo = document.getElementById("parafo");*/
    document.getElementById("parafo").style.backgroundColor = "yellow";
}

function texto() {
    let text = document.getElementById("texto");
    document.getElementById("paf").innerText += text.value + ". ";
}

function Verificar() {
    let edad = document.getElementsByTagName("input")[3].value;
    if ( edad >= 18 ) {
        document.getElementById("pasas").className = "muestra alert alert-success";
        document.getElementById("no_pasas").className = "oculto";
    }
    else {
        document.getElementById("no_pasas").className = "muestra alert-danger";
        document.getElementById("pasas").className = "oculto";
    }
}